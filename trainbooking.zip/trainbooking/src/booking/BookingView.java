package booking;

import model.Passenger;
import model.Train;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookingView {
    private BookingModel bookingModel;

    public BookingView(){
        bookingModel=new BookingModel(this);
    }

    public void init() {
        System.out.println("Welcome to IRCTC");
        Scanner sc=new Scanner(System.in);
        while(true){
            System.out.println("1. Booking\n2. Get PNR status\n3. Booking tickets\n4. Cancel Tickets\n5. Search Passenger\n6. Change ticket status of a passenger\n7. List train routes\n8. Add train routes\n9. Exit");
            System.out.println("Enter your choice: ");
            String choice=sc.nextLine();
            switch (choice){
                case "1":
                    getBookingDetails();
                case "9":
                    return;
                default:
                    System.out.println("Please Enter Valid Choice...");

            }
        }

    }

    private void getBookingDetails() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the From Station: ");
        String from=sc.nextLine();
        System.out.println("Enter the To Station: ");
        String to=sc.nextLine();
        bookingModel.getSearchForAvailableTrain(from,to);
    }

    public void showError(String s) {
        System.out.println(s);
    }

    public void showAllTrain(List<Train> trains) {
        for(Train train:trains){
            System.out.println("Train no: " +train.getTrainNumber()+"\nTrain Name: "+train.getTrainNumber()+"\nDeparture Time: "+train.getDepartureTime()+"\nArrival Time: "+train.getArrivalTime()+"\nFare: "+train.getFare()+"\nTotal Seats: "+train.getTotalSeats());
        }
        System.out.println("--------------------------------");
        getPassengerDetails(trains);
    }

    private void getPassengerDetails(List<Train> trains) {
        List<Passenger> tempPassenger=new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Train No: ");
        int trainNo=sc.nextInt();
        Train searchTrainNo=bookingModel.searchTrainNo(trains,trainNo);
        if(searchTrainNo!=null){
            System.out.println("Enter number of Passenger: ");
            int passenger=sc.nextInt();
            for(int i=0;i<passenger;i++){
                System.out.println("Enter Passenger "+(i+1)+" details: ");
                System.out.println("Enter Name: ");
                String name=sc.nextLine();
                System.out.println("Enter the Age: ");
                int age=sc.nextInt();
                System.out.println("Enter the Gender: ");
                String gender=sc.nextLine();
                Passenger passengerDetail=new Passenger(name,age,gender);
                tempPassenger.add(passengerDetail);
            }
            getPayment(passenger,searchTrainNo,tempPassenger);
        }
        else {
            showError("Not Available");
        }

    }

    public void onSuccess(String s) {
        System.out.println(s);
    }

    public void getPayment(int total,Train train,List<Passenger> tempPassenger) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Total fare"+ (train.getFare()*total));
        while(true){
            System.out.println("Payment");
            System.out.println("1. pay\n2. Cancel\n 3.reschedule");
            String choice=sc.nextLine();
            switch (choice){
                case "1":
                    bookingModel.pay(train,tempPassenger);
            }
        }
    }
}
