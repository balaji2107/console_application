package booking;

import datalayer.TrainDatalayer;
import model.Passenger;
import model.Train;

import java.util.ArrayList;
import java.util.List;

public class BookingModel {
    private BookingView bookingView;
    public BookingModel(BookingView bookingView) {
        this.bookingView=bookingView;
    }

    public void getSearchForAvailableTrain(String from, String to) {
        List<Train> availableTrain= TrainDatalayer.getAvailableTrain(from,to);
        if(availableTrain.size() !=0){
            bookingView.showAllTrain(availableTrain);
        }else {
            bookingView.showError("No Train Available..");
        }
    }

    public Train searchTrainNo(List<Train> trains, int trainNo) {
        for(Train train:trains){
            if(train.getTrainNumber()==trainNo && train.getTotalSeats()!=0){
                return train;
            }
        }
        return null;
    }


    public void pay(Train train, List<Passenger> tempPassenger) {
        
    }
}
