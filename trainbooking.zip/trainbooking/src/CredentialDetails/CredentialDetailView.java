package CredentialDetails;

import java.util.Scanner;

public class CredentialDetailView {
    private CredentialDetailModel credentialDetailModel;

    public CredentialDetailView() {
        this.credentialDetailModel=new CredentialDetailModel(this);
    }

    public void init() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Username ");
        String userName=sc.nextLine();
        System.out.println("Enter the password ");
        String password=sc.nextLine();
        credentialDetailModel.checkValid(userName,password);
    }

    public void showError(String error) {
        System.out.println(error);
    }

    public void againSignIn() {
        Scanner sc=new Scanner(System.in);
        System.out.println("Do You want continue this login(Yes/No): ");
        String login=sc.nextLine();
        if(login.equalsIgnoreCase("yes")){
            init();
        }
        else {
            showError("Thank You!..");
        }
    }
}
