package CredentialDetails;


import booking.BookingView;
import model.Credential;
import traindetails.TrainDetailsView;

public class CredentialDetailModel {
    private CredentialDetailView credentialDetailView;
    private Credential credential=new Credential();
    public CredentialDetailModel(CredentialDetailView credentialDetailView) {
        this.credentialDetailView=credentialDetailView;
    }

    public void checkValid(String userName, String password) {
        if(validUser(userName,password) && credential.getRole().equals("admin")){
            new TrainDetailsView().init();
        }
        else if(validUser(userName,password) && credential.getRole().equals("user")){
            new BookingView().init();
        }
        else {
            credentialDetailView.showError("Invalid Username and password");
            credentialDetailView.againSignIn();
        }

    }

    private boolean validUser(String userName, String password) {
        if(userName.equals("ram") && password.equals("ram123")){
            credential.setUsername("ram");
            credential.setPassword("ram123");
            credential.setRole("user");
            return true;
        }
        else if(userName.equals("bala") && password.equals("bala123")){
            credential.setUsername("bala");
            credential.setPassword("bala123");
            credential.setRole("admin");
            return true;
        }
        return false;
    }
}
