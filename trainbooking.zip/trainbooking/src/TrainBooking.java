import CredentialDetails.CredentialDetailView;


public class TrainBooking {
    public static void main(String[] args) {
        createapp();
    }

    private static void createapp() {
        new CredentialDetailView().init();
    }
}
