package datalayer;

import model.Passenger;
import model.Train;

import java.util.ArrayList;
import java.util.List;

public class TrainDatalayer {

    private static TrainDatalayer trainDatalayer;

    static List<Train> trainDetails=new ArrayList<>();

    static List<Passenger> passengerList=new ArrayList<>();

    public static TrainDatalayer getInstance(){
        if(trainDatalayer==null) {
            trainDatalayer = new TrainDatalayer();
        }
        return trainDatalayer;
    }
    public static List<Train> getAllTrain(){
        return trainDetails;
    }

    public static boolean insertDetail(Train train){
        if(train != null) {
            trainDetails.add(train);
            return true;
        }
        return false;

    }

    public static List<Train> getAvailableTrain(String from, String to) {
        List<Train> getAvail=new ArrayList<>();
        boolean fromTrain=false;
        boolean toTrain=false;
        for(Train train:getAllTrain()){
            for(String route:train.getTrainRoutes()){
                if(from.equalsIgnoreCase(route)){
                    fromTrain=true;
                }
                if(to.equalsIgnoreCase(route)){
                    toTrain=true;
                }
            }
            if(fromTrain && toTrain){
                getAvail.add(train);
            }
        }
        return getAvail;
    }

    public static boolean insertPassenger(Passenger passenger) {
        if(passenger != null) {
            passengerList.add(passenger);
            return true;
        }
        return false;
    }
}
