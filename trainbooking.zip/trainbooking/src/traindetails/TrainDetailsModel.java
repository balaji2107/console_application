package traindetails;

import datalayer.TrainDatalayer;
import model.Train;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TrainDetailsModel {
    private TrainDetailsView trainDetailsView;
    public TrainDetailsModel(TrainDetailsView trainDetailsView) {
        this.trainDetailsView=trainDetailsView;
    }

    public void insertTainDetails(int trainNo, String trainName, String departureTime, String arrivalTime, String routes, int totalSeats,int fare) {
        Train train=new Train();
        train.setTrainNumber(trainNo);
        train.setTrainName(trainName);
        train.setDepartureTime(departureTime);
        train.setArrivalTime(arrivalTime);
        train.setTrainRoutes(getAllRoutes(routes));
        train.setTotalSeats(totalSeats);
        train.setFare(fare);
        if(TrainDatalayer.insertDetail(train)){
            trainDetailsView.onSuccess("Successfully Inserted");
        }
        else{
            trainDetailsView.showError("Record doesn't Inserted");
        }
    }

    private List<String> getAllRoutes(String routes) {
        List<String> getRoutes=new ArrayList<>();
        String[] route=routes.split(",");
        getRoutes.addAll(Arrays.asList(route));
        return getRoutes;
    }
}
