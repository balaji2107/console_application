package traindetails;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TrainDetailsView {
    private TrainDetailsModel trainDetailsModel;
    public TrainDetailsView(){
        trainDetailsModel=new TrainDetailsModel(this);
    }

    public void init() {
        System.out.println("Welcome to Indian Railways..");
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Number of Schedules");
        int schedule=sc.nextInt();
        for(int i=0;i<schedule;i++){
            System.out.println("Schedule "+(i+1));
            System.out.println("Enter the Train Number: ");
            int trainNo=sc.nextInt();
            sc.nextLine();
            System.out.println("Enter the Train Name: ");
            String trainName=sc.nextLine();
            System.out.println("Enter the Train Departure Time like us(HH:MM): ");
            String departureTime=sc.nextLine();
            System.out.println("Enter the Train Arrival Time like us(HH:MM): ");
            String arrivalTime=sc.nextLine();
            System.out.println("Enter the Train Routes(separate with comma like us(,))");
            String routes=sc.nextLine();
            System.out.println("Enter the Train Total Seats ");
            int totalSeats=sc.nextInt();
            System.out.println("Enter the Train fare: ");
            int fare=sc.nextInt();
            trainDetailsModel.insertTainDetails(trainNo,trainName,departureTime,arrivalTime,routes,totalSeats,fare);
        }
    }

    public void onSuccess(String success) {
        System.out.println(success);
    }

    public void showError(String error) {
        System.out.println(error);
    }
}
