package model;

public class Ticket {
    private String trainNumber;
    private String tainName;
    private String departureTime;
    private String ArrivalTime;
    private String fromStation;
    private String toStation;
    private int pnrNo;
    private int totalFare;

    public Ticket(String trainNumber, String tainName, String departureTime, String arrivalTime, String fromStation, String toStation, int pnrNo, int totalFare) {
        this.trainNumber = trainNumber;
        this.tainName = tainName;
        this.departureTime = departureTime;
        ArrivalTime = arrivalTime;
        this.fromStation = fromStation;
        this.toStation = toStation;
        this.pnrNo = pnrNo;
        this.totalFare = totalFare;
    }

    public String getTrainNumber() {
        return trainNumber;
    }

    public void setTrainNumber(String trainNumber) {
        this.trainNumber = trainNumber;
    }

    public String getTainName() {
        return tainName;
    }

    public void setTainName(String tainName) {
        this.tainName = tainName;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalTime() {
        return ArrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        ArrivalTime = arrivalTime;
    }

    public String getFromStation() {
        return fromStation;
    }

    public void setFromStation(String fromStation) {
        this.fromStation = fromStation;
    }

    public String getToStation() {
        return toStation;
    }

    public void setToStation(String toStation) {
        this.toStation = toStation;
    }

    public int getPnrNo() {
        return pnrNo;
    }

    public void setPnrNo(int pnrNo) {
        this.pnrNo = pnrNo;
    }

    public int getTotalFare() {
        return totalFare;
    }

    public void setTotalFare(int totalFare) {
        this.totalFare = totalFare;
    }
}
